<div id="footer">
    <div class="footer">
        <p>MUVIETGAME.NET</p>
        <p>Zalo Admin: 0943465986</p>
    </div>
</div>