<div id="header">
    <div class="header">
        <ul class="header__ul">
            <li><a href="#"><i class="fa-solid fa-house"></i> Trang chủ</a></li>
            <li><a href="#"><i class="fa-solid fa-helicopter-symbol"></i> Hướng dẫn</a></li>
            <li><a href="#"><i class="fa-regular fa-bell"></i> Thông báo</a></li>
            <li><a href="#"><i class="fa-solid fa-money-bill-wave"></i> Nạp thẻ</a></li>
            <li><a href="https://www.facebook.com/muvietgame.net"><i class="fa-brands fa-square-facebook"></i> FANFAGE</a></li>
        </ul>
        
    </div>
    
</div>

