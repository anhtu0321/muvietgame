@extends('fontend/layouts.master')

@section('title')
  <title>MUVIETGAME.NET</title>
@endsection

@section('content')
	<!-- <app-component></app-component> -->
	<div class="content__show">
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
	</div>
@endsection