<div id="banner">
    <div class="banner">
        <img src="lib/public/image/CHU.PNG">
    </div>
</div><?php /**PATH D:\xampp\htdocs\muvietgame\lib\resources\views/fontend/layouts/banner.blade.php ENDPATH**/ ?>