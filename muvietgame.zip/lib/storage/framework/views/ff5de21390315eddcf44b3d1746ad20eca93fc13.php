<?php $__env->startSection('title'); ?>
  <title>MUVIETGAME.NET</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- <app-component></app-component> -->
	<div class="content__show">
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
		<div class="tin">
			<div class="loaitin"><span>Thong bao</span></div>
			<div class="tieudetin"><a href="#">Suw kiem moi o day</a></div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\muvietgame\lib\resources\views/fontend/home.blade.php ENDPATH**/ ?>