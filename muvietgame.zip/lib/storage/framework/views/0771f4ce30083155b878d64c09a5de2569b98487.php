<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="x-ua-compatible" content="ie=edge">
	<?php echo $__env->yieldContent('title'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('lib/public/fontawesome6.4.0/css/all.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('lib/public/bootstrap/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('lib/public/css/mystyle.css')); ?>">

</head>
<body>
	<div class="wrapper" id="app">
		<?php echo $__env->make('fontend/layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('fontend/layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div id="content">
			<div class="content">
				<div class="content__header"></div>
				<div class="content__main">
					<div class="content__sidebar">
						<div class="content__logo">
							<a href="https://drive.google.com/file/d/1OQN6w7_n-szxvNhOWEPPvuC0iFqh4wiL/view?usp=sharing"><img src="lib/public/image/download-logo.png" alt=""></a>
						</div>
						<div class="content__menu">
							<ul>
								<li><a href="#">Hướng dẫn</a></li>
								<li><a href="#">Thông báo</a></li>
								<li><a href="#">Nạp thẻ</a></li>
								<li><a href="https://www.facebook.com/muvietgame.net">FANPAGE</a></li>
							</ul>
						</div>
					</div>
					<div class="content__center">
						<?php echo $__env->yieldContent('content'); ?>
					</div>
				</div>
			</div>
		</div>
		
		<?php echo $__env->make('fontend/layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<script src="<?php echo e(asset('lib/public/build/assets/app-4ed993c7.js')); ?>"></script>
<script src="<?php echo e(asset('lib/public/js/myjs.js')); ?>"></script>
</body>
</html><?php /**PATH D:\xampp\htdocs\muvietgame\lib\resources\views/fontend/layouts/master.blade.php ENDPATH**/ ?>