<div id="footer">
    <div class="footer">
        <p>MUVIETGAME.NET</p>
        <p>Zalo Admin: 0943465986</p>
    </div>
</div><?php /**PATH D:\xampp\htdocs\muvietgame\lib\resources\views/fontend/layouts/footer.blade.php ENDPATH**/ ?>